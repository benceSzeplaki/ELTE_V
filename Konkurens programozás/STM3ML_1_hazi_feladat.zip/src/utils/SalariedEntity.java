package utils;

public interface SalariedEntity {
    Double getSalary();

    void deleteEmployee(SalariedEntity salariedEntity);
}
